# Home - Netherlands - Zorginzage Implementation Guide v1.0.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://nuts-foundation.github.io/nl-zorginzage-ig/ImplementationGuide/fhir.nl.zorginzage | *Version*:1.0.0 |
| Active as of 2026-11-12 | *Computable Name*:NlZorginzageIG |

### Overview

Zorginzage bevat de generieke afspraken en specificaties die het mogelijk maken dat zorgverleners patientdata die zijn opgeslagen bij andere zorgorganisaties op een gebruiksvriendelijke, veilige en schaalbare manier kunnen inzien.

### Organization of This Guide

Deze specificatie is in lijn met de IHE-profielen en de Twiin-zorgtoepassingen opgedeeld in de volgende volumes:

* [Volume 1](vol1.md) geeft een functioneel overzicht en beschrijft de benodigde organisatorische afspraken (in Dutch)
* [Volume 2a](vol2a.md) bevat de technische afspraken (in English)
* [Volume 2b](vol2b.md) bevat alle losse transacties die worden gebruikt (in English)
* [Volume 3](vol3.md) bevat afspraken en specificaties over content (informatie en data) (in English)

### Ondersteuning

Voor ondersteuning bij de interpretatie en implementatie van deze specificatie kunt u zich wenden tot [ActiZ](mailto:DigitaalDenkenenDoen@Actiz.nl).

