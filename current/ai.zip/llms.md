# fhir.nl.zorginzage#1.0.0: Netherlands - Zorginzage Implementation Guide

## Pages

* [Home](index.md)
* [Volume 2a](vol2a.md)
* [Volume 2b](vol2b.md)
* [Artifacts Summary](artifacts.md)
* [Volume 3](vol3.md)
* [History](history.md)
* [Volume 1](vol1.md)

## Resources

### ImplementationGuides

* [Netherlands - Zorginzage Implementation Guide](index.md)

### Examples

* [PatientExample (Patient)](Patient-PatientExample.md)
